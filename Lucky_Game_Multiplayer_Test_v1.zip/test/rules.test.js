const test=require('node:test');const assert=require('node:assert/strict');const rules=require('../rules');
test('free has four participants',()=>{const g=rules.create(['A','B','C','D'],'free');assert.equal(g.players.length,4)});
test('vip has two participants',()=>{const g=rules.create(['A','B'],'vip');assert.equal(g.players.length,2)});
test('snake 37 falls to 15',()=>{const g=rules.create(['A','B'],'vip');g.players[0].pos=34;const out=rules.turn(g,3);assert.equal(out.position,15)});
test('ladder 4 rises to 25',()=>{const g=rules.create(['A','B'],'vip');const out=rules.turn(g,4);assert.equal(out.position,25)});
test('overshoot wins and gives ten points',()=>{const g=rules.create(['A','B'],'vip');g.players[0].pos=99;rules.turn(g,6);assert.equal(g.winner,0);assert.equal(g.players[0].score,10)});
test('timeout skips without rolling',()=>{const g=rules.create(['A','B'],'vip');rules.timeout(g);assert.equal(g.current,1);assert.equal(g.players[0].pos,0)});
