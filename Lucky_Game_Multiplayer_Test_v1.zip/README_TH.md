# Lucky Game v12 — Multiplayer TEST v1

**เฉพาะโปรเจกต์ใหม่ `Lucky-Game-GDevelop`** ไม่แก้ไขโครงการเก่า `Snakes-and-Ladders-Private`

## ทำอะไรได้
- รักษาหน้าตา HTML/CSS ของ Playable v12
- จับคู่ Free 4 คน และ VIP 2 คน ผ่าน WebSocket จากคนละมือถือ
- เซิร์ฟเวอร์เป็นผู้สุ่มลูกเต๋า กำหนดเทิร์น 20 วินาที คำนวณงู บันได Lucky Box และผู้ชนะ
- ผู้ชนะ +10 คะแนน; Lucky Box โอกาส 50%/30%/19%/0.9%/0.1%
- สถานะห้องกระจายไปทุกผู้เล่น, ข้ามเทิร์นเมื่อหมดเวลา, reconnect ด้วย token ภายใน server process เดียวกัน
- โหมดเล่นเครื่องเดียวของ v12 ยังคงอยู่

## ติดตั้ง Codespaces (Node.js 20+)
```bash
cd /workspaces/Lucky-Game-GDevelop
# อัปโหลด ZIP นี้เข้า repository ใหม่ (หรือ Codespaces) แล้ว:
unzip -oq Lucky_Game_Multiplayer_Test_v1.zip -d multiplayer-test
cd multiplayer-test
npm install --no-audit --no-fund
npm test
PORT=8080 npm start
```
ในแท็บ **Ports** เปิดพอร์ต **8080 (Private)** ผ่าน Chrome และเข้า URL เดียวกันจากมือถือ 4 เครื่อง หรือ 2 เครื่องสำหรับ VIP เมื่อใช้บัญชี GitHub เดียวกันและเปิดพอร์ต Private (แต่ละเครื่องต้องเข้าถึงพอร์ตได้)

**ก่อนเริ่ม:** หยุด `python3 -m http.server 8080` ตัวเดิมด้วย `Ctrl+C` ใน Terminal เดิม หรือให้ใช้ port 8081 (`PORT=8081 npm start`) เพื่อไม่ชนพอร์ต 8080

เลือก Free/VIP → กรอกชื่อ → Lobby → กด `เริ่มจับคู่หาห้องออนไลน์` แต่ละเครื่อง จะเริ่มเมื่อผู้เล่นครบจำนวนที่กำหนด; ต้องเปิดคนละ browser profile หรือคนละมือถือสำหรับ token ของแต่ละคน

## ข้อจำกัดสำคัญ
- เป็น **staging TEST** เท่านั้น ข้อมูลห้องอยู่ในหน่วยความจำ หาก Codespaces หยุด ทุกห้องจะหายไป
- ยังไม่มี Google Login, การตรวจสิทธิ์ VIP, คะแนนบัญชีถาวร, leaderboard ข้ามเกม, ระบบชำระเงินจริง, ระบบป้องกันการปลอมชื่อ/โกงระดับ production
- UI v12 แสดงภาพงู/บันไดแบบคงที่ ไม่รองรับการสุ่มกระดาน 5 แบบใน server v1 นี้
- การแสดงผลป๊อปอัปรางวัลแสดงเฉพาะผู้ได้รางวัลในโหมดออนไลน์ แต่ยังต้องตรวจบนมือถือจริง
- การเชื่อมต่อกลับอาศัย token ใน localStorage เพื่อกู้ที่นั่งเดิม; หากล้างข้อมูลเว็บ/เปลี่ยน host อาจไม่ได้ token เดิม
- ไม่ใช้ Cloudflare และไม่ได้อัปโหลดเข้า GDevelop Cloud
- การเปิดพอร์ตให้ผู้เล่นทดสอบ ต้องไม่เปลี่ยนเป็น Public หากยังไม่ได้ตรวจเรื่องการเข้าถึง

## Health
`GET /health` ตรวจจำนวนห้องทดสอบและคนรอจับคู่
