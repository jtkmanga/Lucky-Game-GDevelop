'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer, WebSocket } = require('ws');
const Rules = require('./rules.js');
const PORT = Number(process.env.PORT || 8080);
const WEB = path.resolve(__dirname,'public');
const waiting = {free:[],vip:[]};
const rooms = new Map();
const sessions = new Map();
const TURN_MS=20000;
let sequence=0;
const capacity = mode => mode === 'vip' ? 2 : 4;
function send(ws,obj){if(ws && ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(obj));}
function broadcast(room, kind='state',extra={}){
 for(const seat of room.seats)send(seat.ws,{type:kind,roomId:room.id,seat:seat.index,game:room.game,deadline:room.deadline,...extra});
}
function closeRoom(room){if(room.timer)clearTimeout(room.timer);rooms.delete(room.id);for(const s of room.seats){if(s.ws?.readyState===WebSocket.OPEN)send(s.ws,{type:'room_closed'});sessions.delete(s.token);}}
function nextDeadline(room){
 if(room.timer)clearTimeout(room.timer);
 if(room.game.over){room.deadline=null;return;}
 room.deadline=Date.now()+TURN_MS;
 const turn=room.game.turn;
 room.timer=setTimeout(()=>{
  if(room.game.over||room.game.turn!==turn)return;
  Rules.timeout(room.game);nextDeadline(room);broadcast(room,'state',{event:{type:'timeout'}});
 },TURN_MS);
 room.timer.unref?.();
}
function leaveQueue(session){
 const q=waiting[session.mode];if(!q)return;
 const i=q.indexOf(session);if(i>=0)q.splice(i,1);
}
function dispatch(mode){
 const q=waiting[mode];
 while(q.length>=capacity(mode)){
  const seats=q.splice(0,capacity(mode));
  const game=Rules.create(seats.map(s=>s.name),mode);
  for(const [i,s] of seats.entries()){
   s.index=i;s.roomId='room-'+(++sequence);game.players[i].avatar=s.avatar;
  }
  const id=seats[0].roomId;
  for(const s of seats)s.roomId=id;
  const room={id,mode,seats,game,deadline:0,timer:null};rooms.set(id,room);
  nextDeadline(room);
  broadcast(room,'state',{event:{type:'start'}});
 }
 for(const [i,s] of q.entries())send(s.ws,{type:'waiting',mode,joined:i+1,needed:capacity(mode),token:s.token});
}
function attach(ws,s){
 s.ws=ws;ws.session=s;
 send(ws,{type:'identity',token:s.token});
 if(s.roomId){const room=rooms.get(s.roomId);if(room){send(ws,{type:'state',roomId:room.id,seat:s.index,game:room.game,deadline:room.deadline,event:{type:'resume'}});return;}}
 send(ws,{type:'waiting',mode:s.mode,joined:waiting[s.mode].indexOf(s)+1,needed:capacity(s.mode)});
}
function handler(ws,msg){
 if(!msg||typeof msg!=='object'||Array.isArray(msg))return;
 if(msg.type==='join'){
  if(ws.session){send(ws,{type:'error',message:'เชื่อมต่อห้องอยู่แล้ว'});return;}
  const resumed=typeof msg.token==='string' ? sessions.get(msg.token) : null;
  if(resumed){if(resumed.ws && resumed.ws!==ws && resumed.ws.readyState===WebSocket.OPEN)resumed.ws.close(4000,'reconnected');attach(ws,resumed);return;}
  const mode=msg.mode==='vip'?'vip':'free';
  const name=String(msg.name||'ผู้เล่น').trim().slice(0,20)||'ผู้เล่น';
  const avatar=typeof msg.avatar==='string' && msg.avatar.length<=12?msg.avatar:'🐱';
  const s={name,avatar,mode,token:crypto.randomBytes(24).toString('hex'),ws,index:null,roomId:null};
  sessions.set(s.token,s);waiting[mode].push(s);attach(ws,s);dispatch(mode);return;
 }
 const s=ws.session;if(!s||s.ws!==ws)return;
 if(msg.type==='cancel' && !s.roomId){leaveQueue(s);sessions.delete(s.token);ws.session=null;send(ws,{type:'cancelled'});dispatch(s.mode);return;}
 if(msg.type==='roll'){
  const room=rooms.get(s.roomId);
  if(!room||room.game.over){send(ws,{type:'error',message:'ห้องไม่พร้อม'});return;}
  if(room.game.current!==s.index){send(ws,{type:'error',message:'ยังไม่ถึงตาของคุณ'});return;}
  if(Date.now()>=room.deadline){send(ws,{type:'error',message:'หมดเวลาแล้ว'});return;}
  const actor=s.index;
  const dice=crypto.randomInt(1,7);
  const outcome=Rules.turn(room.game,dice);
  nextDeadline(room);
  broadcast(room,'state',{event:{type:'roll',actor,dice,outcome}});
 }
}
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/health'){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({ok:true,rooms:rooms.size,waiting:{free:waiting.free.length,vip:waiting.vip.length},note:'test server / in-memory'}));return;}
 const filepath=path.join(WEB,u.pathname==='/'?'index.html':u.pathname);
 if(!filepath.startsWith(WEB+path.sep)||!fs.existsSync(filepath)||!fs.statSync(filepath).isFile()){res.writeHead(404);res.end('Not found');return;}
 res.writeHead(200,{'content-type':filepath.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream','cache-control':'no-store','x-content-type-options':'nosniff'});fs.createReadStream(filepath).pipe(res);
});
const wss=new WebSocketServer({server,path:'/ws',maxPayload:2048});
wss.on('connection',ws=>{
 let last=0;
 ws.on('message',raw=>{
  const now=Date.now();if(now-last<100)return;last=now;
  try{handler(ws,JSON.parse(raw.toString()));}catch(e){send(ws,{type:'error',message:'คำสั่งไม่ถูกต้อง'});}
 });
 ws.on('close',()=>{const s=ws.session;if(s&&s.ws===ws){s.ws=null;if(!s.roomId){leaveQueue(s);dispatch(s.mode);sessions.delete(s.token);}}});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Lucky Multiplayer TEST listening at http://0.0.0.0:${PORT} (Free 4 / VIP 2; temporary sessions; no billing)`));
process.on('SIGINT',()=>{for(const r of rooms.values())clearTimeout(r.timer);server.close(()=>process.exit(0));});
