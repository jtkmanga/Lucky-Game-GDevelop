#!/usr/bin/env bash
# Lucky Game: experimental GDevelop Desktop via GitHub Codespaces + noVNC
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive

if [[ "$(uname -m)" != "x86_64" ]]; then
  echo 'This setup supports x86_64 Codespaces only.' >&2
  exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo 'Requires an Ubuntu/Debian Codespace.' >&2
  exit 1
fi
if [[ -z "${CODESPACES:-}" && -z "${CODESPACE_NAME:-}" ]]; then
  echo 'Warning: this script is intended for GitHub Codespaces.' >&2
fi

echo '[1/5] Installing virtual desktop packages (may consume Codespaces storage and compute quota)'
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends \
  xfce4 xfce4-terminal xfce4-session dbus-x11 \
  tigervnc-standalone-server tigervnc-tools novnc websockify \
  curl jq ca-certificates xz-utils libgtk-3-0 libnss3 libasound2 \
  libxss1 libgbm1 libatk-bridge2.0-0 libdrm2 libxkbcommon0 || {
  echo 'Package install failed; Ubuntu image may require different dependencies.' >&2
  exit 1
}

BASE="$HOME/.local/share/lucky-gdevelop-desktop"
mkdir -p "$BASE" "$HOME/.vnc" "$HOME/Desktop"
if [[ ! -f "$HOME/.vnc/passwd" ]]; then
  echo '[2/5] Create a VNC password (8-character significant limit in classic VNC).'
  echo 'Use a unique password; this is in addition to private Codespaces port access.'
  vncpasswd
fi
cat > "$HOME/.vnc/xstartup" <<'START'
#!/usr/bin/env bash
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
exec dbus-launch --exit-with-session startxfce4
START
chmod +x "$HOME/.vnc/xstartup"

APP="$BASE/GDevelop.AppImage"
if [[ ! -s "$APP" ]]; then
  echo '[3/5] Downloading latest stable Linux x86_64 AppImage from official GDevelop GitHub releases'
  RELEASE_JSON="$(curl -fsSL --retry 3 https://api.github.com/repos/4ian/GDevelop/releases/latest)"
  URL="$(printf '%s' "$RELEASE_JSON" | jq -r '[.assets[] | select(.name | test("(?i)\\.AppImage$") and (test("(?i)arm64|aarch64")|not))] | .[0].browser_download_url // empty')"
  if [[ -z "$URL" ]]; then
    echo 'Could not find official x86_64 GDevelop AppImage. See https://github.com/4ian/GDevelop/releases' >&2
    exit 1
  fi
  curl -fL --retry 3 --progress-bar "$URL" -o "$APP.tmp"
  mv "$APP.tmp" "$APP"
  chmod +x "$APP"
fi

cat > "$BASE/start-gdevelop.sh" <<'RUN'
#!/usr/bin/env bash
set -e
cd "$HOME/.local/share/lucky-gdevelop-desktop"
# Container-only workaround: Electron normally needs an OS sandbox not provided by Codespaces.
export LIBGL_ALWAYS_SOFTWARE=1
export APPIMAGE_EXTRACT_AND_RUN=1
exec ./GDevelop.AppImage --no-sandbox --disable-gpu --disable-dev-shm-usage
RUN
chmod +x "$BASE/start-gdevelop.sh"
cat > "$HOME/Desktop/GDevelop.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=GDevelop Desktop
Exec=$BASE/start-gdevelop.sh
Icon=applications-games
Terminal=false
Categories=Development;Game;
EOF2
chmod +x "$HOME/Desktop/GDevelop.desktop"

if ! vncserver -list 2>/dev/null | grep -q ':1'; then
  echo '[4/5] Starting password-protected local VNC desktop'
  vncserver :1 -localhost yes -geometry 1280x850 -depth 24
fi

# A GitHub Codespaces port is private unless the user changes its visibility.
if ! pgrep -f 'websockify.*6080.*localhost:5901' >/dev/null 2>&1; then
  nohup websockify --web=/usr/share/novnc 0.0.0.0:6080 localhost:5901 > "$BASE/novnc.log" 2>&1 &
fi
sleep 2

# Launch GDevelop inside the virtual desktop, even when XFCE is not fully ready.
DISPLAY=:1 nohup "$BASE/start-gdevelop.sh" > "$BASE/gdevelop.log" 2>&1 &

echo '[5/5] Ready to try. In Codespaces PORTS tab, open PRIVATE port 6080.'
echo 'URL path: /vnc.html'
echo 'Enter the VNC password you created above.'
echo 'GDevelop executable can take time to extract and load; check ~/.local/share/lucky-gdevelop-desktop/gdevelop.log if needed.'
echo 'Open downloaded LuckyGame_GDevelop.json via File > Open, then File > Save As > GDevelop Cloud.'
echo 'Do not expose port 6080 publicly; this is a desktop GUI with your authenticated GDevelop session.'
