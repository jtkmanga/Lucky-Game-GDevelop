# Lucky Game — แนวทางนำเข้า GDevelop Cloud ผ่าน Codespaces (ทดลอง)

**เป้าหมาย:** เปิด GDevelop Desktop รุ่น Linux บน Codespaces ด้วยจอเสมือน แล้วเข้าหน้าจอจากมือถือผ่าน noVNC; เปิดไฟล์โปรเจกต์จากดิสก์ Codespaces และใช้เมนู GDevelop Desktop → Save As → GDevelop Cloud

## สิ่งที่ตรวจยืนยันแล้ว

- GDevelop Web Editor บนมือถือไม่เปิดไฟล์ JSON ในเครื่องจากเมนู File → Open (จากภาพหน้าจอของเจ้าของโครงการ)
- เอกสารทางการ GDevelop ระบุว่า MCP สำหรับ AI Agent ใช้ได้ใน Desktop เท่านั้น และ Agent ต้องอยู่เครื่องเดียวกับ GDevelop (https://wiki.gdevelop.io/gdevelop5/interface/ai/mcp/)
- มี GDevelop Linux AppImage ใน official GitHub Releases (https://github.com/4ian/GDevelop/releases)
- โปรเจกต์ต้นฉบับใน ZIP มี Lobby, Board และ assets; ยังไม่ได้ตรวจเปิดจริงใน GDevelop Desktop หรือทดสอบ Multiplayer

## สถานะสำคัญ

**สคริปต์นี้ยังไม่ได้รันจริงใน GitHub Codespaces และไม่ได้ตรวจว่า GUI GDevelop Desktop ทำงานสมบูรณ์หรือเข้าถึง GDevelop Cloud ได้ในสภาพแวดล้อมนั้น** จึงยังไม่รับประกันว่าจะสำเร็จ ไม่มีการนำเข้า Cloud จริงในชุดนี้

## ข้อควรระวังเรื่องค่าใช้จ่ายและข้อมูลบัญชี

- การเปิด Codespaces ใช้ quota เวลา compute และ storage ของ GitHub; ไม่ใช่การรับประกันว่าไม่มีค่าใช้จ่าย
- การติดตั้ง desktop dependencies และ GDevelop AppImage อาจใช้พื้นที่หลายร้อย MB ถึงหลาย GB
- เก็บพอร์ต `6080` เป็น **Private** ห้ามตั้ง Public เพราะสามารถควบคุมหน้าจอที่ล็อกอินบัญชี GDevelop ของคุณได้
- สร้างรหัส VNC แยกจาก GitHub และ GDevelop และห้ามเปิดเผยในแชต
- ห้ามใช้โปรเจกต์เดิมใน GDevelop ให้เปิดโปรเจกต์ใหม่จากชุดนี้และบันทึกเป็นชื่อใหม่

## การทดลอง (เมื่ออนุญาตใช้ quota Codespaces)

1. เปิด Codespace ใหม่ที่ใช้ Ubuntu/Debian, architecture x86_64
2. อัปโหลด ZIP นี้จากมือถือเข้า Codespaces ด้วยฟังก์ชัน upload ของ VS Code Web หรือใส่เป็นไฟล์ใน repo ใหม่ (ไม่ใช่ repo เกมเก่า)
3. แตกไฟล์ แล้วเปิด Terminal ในโฟลเดอร์ชุดนี้
4. รัน `bash setup-remote-gdevelop.sh` (ติดตั้งโปรแกรม; อาจใช้เวลาหรือกิน quota)
5. เลือก Codespaces → PORTS → `6080` → **Private** → Open in Browser จากมือถือ และเปิด `/vnc.html`
6. ใช้รหัส VNC ที่ตั้งเองแล้วเปิด GDevelop Desktop ในจอเสมือน
7. แตกไฟล์ `LuckyGame_GDevelop_Starter_v1.zip` ใน Codespaces ให้คง assets/ แล้วเปิด `lucky-game-gdevelop-v1/LuckyGame_GDevelop.json` ด้วย GDevelop Desktop
8. ตรวจภาพ Lobby, Board และ JS Events ก่อนบันทึก GDevelop Cloud ด้วย **File → Save As** เป็นเกมใหม่ ไม่ทับเกมเก่า

## ถ้าเกิดปัญหา

- GDevelop เปิดไม่ได้: ตรวจ `~/.local/share/lucky-gdevelop-desktop/gdevelop.log`
- noVNC เปิดไม่ได้: ตรวจ `~/.local/share/lucky-gdevelop-desktop/novnc.log`; ตรวจว่าพอร์ต 6080 ยัง Private
- ถ้าบันทึก GDevelop Cloud ไม่สำเร็จ ให้หยุดก่อนและตรวจ error; **อย่า** อัปโหลดผ่าน API ที่ไม่มีเอกสารหรือคัดลอก credential
- ต้องใช้ GDevelop Desktop ไม่ใช่การเปิด `editor.gdevelop.io` ในแท็บ Codespaces; Web Editor ก็ยังจำกัดการนำเข้าไฟล์เช่นเดิม

## วิธีที่ง่ายกว่า ถ้าสคริปต์นี้ไม่ผ่าน

ใช้แอป GDevelop Desktop บนเครื่อง Linux/Windows/macOS ที่คุณเข้าถึงด้วย Remote Desktop ครั้งเดียวเพื่อ Import และ Save As → Cloud จากนั้นกลับไปแก้ใน GDevelop Web Editor บนมือถือได้ โดยไม่ต้องใช้ Cloudflare หรือเปลี่ยน UI ต้นฉบับ
