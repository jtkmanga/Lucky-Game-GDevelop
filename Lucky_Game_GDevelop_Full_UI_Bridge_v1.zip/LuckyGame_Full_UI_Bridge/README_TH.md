# Lucky Game — GDevelop Full UI Bridge v1 (ทดลองเท่านั้น)

## สิ่งที่ทำเสร็จ
- สร้างฉาก `OriginalUIv12` เป็นฉากเริ่มต้นใน GDevelop
- รักษา HTML/CSS/JS ทั้งชุดจาก `Lucky_Game_Playable_v12.html` (ไม่ลดรายละเอียด UI)
- ใช้ JavaScript event สร้าง iframe ที่แสดงหน้า UI ต้นฉบับภายในหน้าต่าง GDevelop Preview
- เก็บฉาก `Lobby` และ `Board` native ของ Starter v1 ไว้เป็นข้อมูลอ้างอิง
- ไม่มีการเชื่อม GitHub เกมเดิมหรือ Cloudflare และไม่มีการ deploy

## วิธีนำเข้า
1. สำรองโปรเจกต์เดิมและแตก zip ลงใน Codespaces โฟลเดอร์ใหม่
2. ใน GDevelop Desktop เลือก File > Open > `LuckyGame_Full_UI_Bridge.json`
3. กด Preview: ต้องแสดง UI v12 เดิม (ถ้า JavaScript event เข้าถึง DOM ใน GDevelop Runtime เวอร์ชันที่ติดตั้ง)
4. หากดำหรือเกิด error ให้เปิด Debugger/Developer Tools และตรวจ Console; กลับไฟล์ Starter เดิมได้ทันที

## ข้อจำกัดสำคัญ
- วิธีนี้เป็น **HTML-in-GDevelop hybrid** ไม่ใช่ UI ที่แปลงเป็น object/scene native ของ GDevelop
- ภายใน HTML ยังเป็น **เกม local** 4 หรือ 2 คนในเครื่องเดียว ไม่ใช่ Multiplayer ข้ามมือถือ
- ยังไม่ได้ยืนยันการทำงานจริงบน Codespaces GDevelop Preview; ผล zip นี้ผ่านการตรวจ JSON และไวยากรณ์ JavaScript แบบ static เท่านั้น
- หน้าตา CSS เป็นของ HTML ต้นฉบับ; ฟอนต์ Kanit ใช้บริการ Google Fonts ถ้าออนไลน์
- ห้ามใช้เพื่อเปิดให้ผู้เล่นจริงก่อนมี backend, authentication, leaderboard และ payment ที่ผ่านการตรวจสอบ
- iframe จะทับการแสดงผลของ Canvas ใน Preview ขณะอยู่ในฉาก OriginalUIv12
- การเปลี่ยนเป็น GDevelop native ต้องสร้าง UI objects, events และ multiplayer อีกระยะหนึ่ง

## การทดสอบในเบราว์เซอร์โดยไม่ใช้ GDevelop (วิธีสำรอง)
`python3 -m http.server 8080 --bind 0.0.0.0` ในโฟลเดอร์ที่มี `Lucky_Game_Playable_v12.html`
จาก Codespaces Ports เปิด 8080 เป็น Private และเข้าที่ `/Lucky_Game_Playable_v12.html`

## เป้าหมายในขั้นต่อไป
แปลง Lobby และ Board เป็นฉาก native ให้ครบตาม v12 พร้อมแยกสถานะ Free/VIP และเซิร์ฟเวอร์เกมจริง
